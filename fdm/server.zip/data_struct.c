#include "data_struct.h"
#include <string.h>
#include <stdio.h>

int dlink_ifnot_empty(dlink_list * list)
{
  return (list->head != 0);
}


void dlink_list_init(dlink_list * list)
{
  list->cnt = 0;
  list->head = list->tail = 0;
}

int dlink_listCount(dlink_list * list)
{
  return list->cnt;
}

void dlinkAdd(void *data, dlink_node * m, dlink_list * list)
{
    m->data = data;
    m->prev = NULL;
    m->next = list->head;
    if (list->head)
        list->head->prev = m;
    list->head = m;
    if (list->tail == NULL)
        list->tail = m;
    list->cnt++;
}

void dlinkAddTail(void *data, dlink_node * m, dlink_list * list)
{
    m->data = data;
    m->next = NULL;
    m->prev = list->tail;
    if (list->tail)
        list->tail->next = m;
    list->tail = m;
    if (list->head == NULL)
        list->head = m;
    list->cnt++;
}

void dlinkDelete(dlink_node * m, dlink_list * list)
{
    if (m->next)
        m->next->prev = m->prev;
    if (m->prev)
        m->prev->next = m->next;
    if (m == list->head)
        list->head = m->next;
    if (m == list->tail)
        list->tail = m->prev;
    m->next = m->prev = NULL;
    list->cnt--;
}


void wordlistDestroy(wordlist ** list)
{
    wordlist *w = NULL;
    while ((w = *list) != NULL) {
        *list = w->next;
        free(w->key);
        w->key = NULL;
        free(w);
    }
    *list = NULL;
}

const char * wordlistAdd(wordlist ** list, const char *key)
{
    while (*list)
        list = &(*list)->next;
    *list = (wordlist *) malloc(sizeof(wordlist));
    (*list)->key = strdup(key);
    (*list)->next = NULL;
    return (*list)->key;
}

void wordlistJoin(wordlist ** list, wordlist ** wl)
{
    while (*list)
        list = &(*list)->next;
    *list = *wl;
    *wl = NULL;
}

void wordlistAddWl(wordlist ** list, wordlist * wl)
{
    while (*list)
        list = &(*list)->next;
    for (; wl; wl = wl->next, list = &(*list)->next) {
        *list = (wordlist *) malloc(sizeof(wordlist));
        (*list)->key = strdup(wl->key);
        (*list)->next = NULL;
    }
}

void wordlistCat(const wordlist * w, char * mb)
{
    while (NULL != w) {
      sprintf(mb, "%s\n", w->key);
      w = w->next;
    }
} 

wordlist * wordlistDup(const wordlist * w)
{
    wordlist *D = NULL;
    while (NULL != w) {
        wordlistAdd(&D, w->key);
        w = w->next;
    }
    return D;
}

 
void data_struct_init(void)
{
	/* empty */
}
