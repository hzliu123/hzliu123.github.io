#define ETHREAD_IMP
#include "data_struct.h"
#include "ethread.h"
#include <signal.h>
#include <errno.h>
#include <sys/poll.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sched.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>

#ifdef _USE_FDM_LIBRARY
#include "../fdm/fdm.h"
#endif


#define NULL 0
#ifdef _RT_USE_SELECT
#define MAX_WAITING_LENGTH FD_SETSIZE
#else
#define MAX_WAITING_LENGTH 8192
#endif


int cnt_hangup = 0;
int stksize = MIN_STACK_SZ;
extern int rtsig;

struct _ethread_state_entry {
  int state;
  char * name;
  char * explain;
} ethread_state_table[PS_MAX] = {
  { PS_SYSTEM,  "SYS", "System Scheduler" },
  { PS_RUNNING, "RUN", "Running EThread" },
  { PS_FD_WAIT, "FD", "Waiting fd status" },
  { PS_WAIT_WAIT, "LOCK", "Sleeping in ELock" },
  { PS_READY, "READY", "Waiting for schedule" },
  { PS_DEAD, "DEAD", "Waiting for collection" }
};

static unsigned int poll_cnt[1 - POLL_ABORT];
static char * poll_str[1 - POLL_ABORT] = {
  "OK",
  "INVALID",
  "HANGUP",
  "ERROR",
  "TIMEOUT",
  "ABORT" 
};
static unsigned int poll_times = 0;
static unsigned int empty_poll_times = 0;


int context_switch = 0;

ethread sys_thread;
ethread *run_thread;
queue_t *ready_queue;

static dlink_list  active_list;

enum { Role_system, Role_thread ,Role_sys_2_thread ,Role_thread_2_sys} role;
static int max_stack_usage = 0;

static int context_switch_to_sys();
static int context_switch_to_thread();
static int ethread_compare(ethread *A, ethread *B);
static int queue_size2(queue_t *qu);
static int poll_fd(void);
static queue_t *init_queue2();
static void put_queue2(queue_t *qu, ethread *this);
static void *get_queue2(queue_t *qu);
static void machdep_ethread_create(ethread *thread, void *(* start_routine)(), void *start_argument);
static void machdep_ethread_start(void);
static void travel_queue2(queue_t *qu, int para,void(*action)(ethread *, int));


struct timeval current_time;

time_t getCurrentTime(void) 
{
#if GETTIMEOFDAY_NO_TZP
  gettimeofday(&current_time);
#else
  gettimeofday(&current_time, NULL);
#endif

  return current_time.tv_sec;
}                                                                               

static int ethread_compare(ethread *A, ethread *B)
{
  if (A->time > B->time)
    return 1;
  else   if (A->time < B->time)
    return -1;
  return 0;
}

int ethread_system_is_empty(void)
{
   return !(dlink_ifnot_empty(&active_list));
}





void ethread_shutdown(void)
{
#ifdef _USE_FDM_LIBRARY
  fdm_stop();
#endif
}



/* ==============================================================
 * machdep_ethread_start()
 */
static void machdep_ethread_start(void)
{
    /* Run current threads start routine with argument */
  role = Role_thread;
  run_thread->start_routine(run_thread->start_argument);
  
  ethread_exit(0);
  /* should never reach here */
}

/* ==========================================================================
 * machdep_ethread_create()
 */

static void machdep_ethread_create(ethread *thread, void *(* start_routine)(), void *start_argument)
{
    thread->start_routine = start_routine;
    thread->start_argument = start_argument;
    
    setjmp(thread->machdep_state);
    /*
     * Set up new stact frame so that it looks like it
     * returned from a longjmp() to the beginning of
     * machdep_ethread_start().
     */
    thread->machdep_state->__jmpbuf[JB_PC] = (int) machdep_ethread_start;

    /* Stack starts high and builds down. */
    thread->machdep_state->__jmpbuf[JB_SP] =      ((int )thread->stack) + thread->stacksize;
}

/* ===================================================================
 * ethread_create()
 *
 * After the new thread structure is allocated and set up, it is added to
 * run_thread_next_queue, 
 */
int ethread_id_global; 
int ethread_create(void * (*start_routine)(void *), void *arg)
{
  ethread *new_thread;
  

  if ((new_thread = (ethread *) malloc(sizeof(ethread)))) {
    
    new_thread->ID = ethread_id_global++;
    
    // ethread id wrapping
    if(ethread_id_global >= 999999) ethread_id_global = 65535;

    /* Get a stack, if necessary */
    new_thread->stack = (void *) malloc(stksize);
    assert(new_thread->stack != NULL);
    memset(new_thread->stack, 0, stksize);
    new_thread->stacksize = stksize;
    machdep_ethread_create(new_thread, start_routine, arg);

    new_thread->state = PS_READY;
    new_thread->getin_time = new_thread->time = getCurrentTime();
    
    
    // Put thread in active list
    dlinkAdd(new_thread, &new_thread->active_link, &active_list);

    put_queue2(ready_queue, (void *) new_thread);

    return(new_thread->ID);
  }
  perror("No space available for ethread\n");
  return(-1);
}


/* ========================================================
 * context_switch()
 *
 * This routine saves the current state of the running thread gets
 * the next thread to run and restores it's state. Use the machdep_restore_state()
 * this is for implementations which use setjmp/longjmp.
 */
static int context_switch_to_sys()
{
  /* save state of current thread */
  if (setjmp(run_thread->machdep_state)) {
    role = Role_thread;
    errno = run_thread->err_num;

    /* Check Stack Usage */
    stack_check();
    
    return run_thread->ret;
  }
  role = Role_thread_2_sys;
  run_thread->err_num = errno;
  run_thread->time = getCurrentTime();

  assert((unsigned int) (run_thread->machdep_state->__jmpbuf[JB_SP]) - (unsigned int)run_thread->stack <= stksize);
  longjmp(sys_thread.machdep_state, 1);
}


static int context_switch_to_thread()
{
  /* save state of system */
  if (setjmp(sys_thread.machdep_state)) {
    role = Role_system;
    context_switch++;

    assert(run_thread);
    if (run_thread->state == PS_DEAD) {
      if (run_thread->stack)
         free(run_thread->stack);
      free(run_thread);
    }
    return 0;
  }
  assert(run_thread);
  assert(run_thread->machdep_state->__jmpbuf[JB_SP]);
  assert(run_thread->machdep_state->__jmpbuf[JB_PC]);
  role = Role_sys_2_thread;
  longjmp(run_thread->machdep_state, run_thread->ret);
}



#ifdef _USE_FDM_LIBRARY

fdm_event_t fdm_poll_fd[MAX_WAITING_LENGTH];

#else


#ifdef _RT_USE_SELECT
fd_set rfd;
fd_set wfd;
fd_set result_rfd;
fd_set result_wfd;
int maxfd = 0;
#else
int open_fd_cnt;
struct pollfd waiting_fd[MAX_WAITING_LENGTH];
#endif

waiting_entry waiting_list[MAX_WAITING_LENGTH];


#ifdef _RT_USE_SELECT
static void collect_waiting_fd(void)
{
  int i, newmax = 0, oldmax = maxfd;
  
  for (i=0; i<oldmax; i++)
     if (waiting_list[i].thread != NULL)
        newmax = i+1;

  maxfd = newmax;        
}
#else
static void collect_waiting_fd(void)
{
  int i,cnt=0;
  struct pollfd *of, *nf;
  waiting_entry *ot,*nt;

  of = nf = &waiting_fd[0];
  ot = nt = &waiting_list[0];
  for (i = 0; i < open_fd_cnt; i++, of++, ot++)
    if (of->fd > 0) {
      if (nf!=of) {
        *nf = *of;
        *nt = *ot;
      }
      cnt++;
      nf++; nt++;
    }
  open_fd_cnt = cnt;
}
#endif

#endif

/* ==============================================================
 * ethread_init()
 *
 */

void ethread_init(void)
{
  int i;

#ifdef _USE_FDM_LIBRARY
  fdm_start();
#endif

#ifdef _RT_USE_SELECT
  FD_ZERO(&rfd);
  FD_ZERO(&wfd);
  
  for (i=0; i<MAX_WAITING_LENGTH; i++)
    waiting_list[i].thread = NULL;
#endif

  for(i=0; i<= 0 - POLL_ABORT; i++) {
    poll_cnt[i] = 0;
  }

  //  struct machdep_ethread machdep_data = MACHDEP_ETHREAD_INIT;

  /* Initialize the first thread */
  ready_queue = (queue_t *) init_queue2();

  sys_thread.state = PS_SYSTEM;
  sys_thread.ID = ethread_id_global++;
  run_thread = 0;

  dlink_list_init(&active_list);
}



#ifdef _USE_RTSIGNALS
int sigio_cnt=0;
int sig_cnt=0;
#endif

/* This is the main handler for each thread.
   It first check if there are open socket that are waiting for some I/O.
          If yes, using poll to check and dispatch.
          if no, release all of outstanding tasks to their I/O socket.

   If there is even no outstanding task, let me go to wait on a conditon.
        The condition will be signal if there is a new task that has been
	enqueued to this thead.                    */

static int poll_fd(void)
{
  int i,revents;

#ifndef _USE_FDM_LIBRARY
  int del;
  int poll_stat;
#ifndef _RT_USE_SELECT
  struct pollfd *p;
#endif
  waiting_entry *w;
#endif  
  ethread *this;
#if defined(_USE_FDM_LIBRARY)
  int e_cnt;
#endif
#if defined(_USE_RTSIGNALS)

#define SIGINFO_SIZE 10
  sigset_t sset;
  siginfo_t sinfo;
  struct timespec ts;
  static int topoll = 0;
  int sig, sig_count;
#ifdef _RT_USE_SELECT
  struct timeval select_timeout; 
#endif  

  sigemptyset(&sset);
  sigaddset(&sset, SIGIO);
  sigaddset(&sset, rtsig);
#endif    

  poll_times++;

#ifndef _USE_FDM_LIBRARY
#ifdef _RT_USE_SELECT
    if (maxfd == 0) return 0;
    
    FD_ZERO(&result_rfd);
    FD_ZERO(&result_wfd);
#else
    if (open_fd_cnt==0) {
      return 0;
    } 

    for (i=0; i<open_fd_cnt; i++) {
      waiting_fd[i].revents = 0;
    }
#endif
#endif

#if defined(_USE_RTSIGNALS)
	
	/* RT signal event handle */

	ts.tv_sec = 0;
	ts.tv_nsec = 0;

	if (topoll) goto rt_process_exit;

	memset(&sinfo, 0, sizeof(sinfo));
	sig_count = 0;
	
	while ((sig = sigtimedwait(&sset, &sinfo, &ts)) > 0) {
		sig_cnt++;
		if (sig == rtsig) {
			sig_count++;
#ifdef _RT_USE_SELECT
		if (sinfo.si_band & POLLIN) {
			FD_SET(sinfo.si_fd, &result_rfd);
		} else if (sinfo.si_band & POLLOUT) {
			FD_SET(sinfo.si_fd, &result_wfd);
		}
#else	
			/* for loop here is significant slow and not scalable */
			for (i=0; i<open_fd_cnt; i++)
				if (waiting_fd[i].fd == sinfo.si_fd)
					waiting_fd[i].revents = sinfo.si_band;
#endif					
		} else if (sig == SIGIO) {
			printf("sig=(%d==SIGIO) fd=%d band=%ld\n", sig, sinfo.si_fd, sinfo.si_band);
			sigio_cnt++;
			topoll = 1;
			break;
		}
		if (sig_count >= SIGINFO_SIZE) break;
        }

	if (sig_count > 0) {
		poll_stat = sig_count;
		goto convert_event;
	} 
	if (!topoll) {
		poll_stat = 0;
		goto convert_event;
	}

rt_process_exit:
	topoll = 0;
	while (sigtimedwait(&sset, &sinfo, &ts) > 0);
#endif

#if defined(_USE_FDM_LIBRARY)

	e_cnt = fdm_wait_event(fdm_poll_fd, MAX_WAITING_LENGTH, 0);

	for (i=0; i<e_cnt; i++) {
		this = (ethread *)fdm_poll_fd[i].payload;
	        assert(this != NULL);
/*                if (this == NULL || this->state != PS_FD_WAIT) continue; */
		/* this might be NULL, because ethread doesn't
	           schedule all thread into sleep_on_fd mode
                   before another poll_fd().
                   When a thread is not in sleep_on_fd mode,
                   this event has no meaning at all.
                 */
                 
		revents = fdm_poll_fd[i].events;

		if (revents & POLLTIMEOUT) {
			this->ret = POLL_TIMEOUT;
		} else if (revents & POLLHUP) {
			cnt_hangup++;
			this->ret = POLL_HANGUP;
      		} else if (revents & POLLERR) {
			this->ret = POLL_ERROR;
      		} else if (revents & POLLNVAL) {
			this->ret = POLL_NVAL;
      		} else {
			this->ret = POLL_OK;
      		}

		poll_cnt[0 - this->ret]++;

		assert(this->state == PS_FD_WAIT);
		this->state = PS_READY;
		put_queue2(ready_queue, this);
      	}

	return e_cnt;
#else

#ifdef _RT_USE_SELECT
    result_rfd = rfd;
    result_wfd = wfd;
    select_timeout.tv_sec = 0;
    select_timeout.tv_usec = 0;    

    if ((poll_stat = select(maxfd, &result_rfd, &result_wfd, NULL, &select_timeout)) < 0)
       return poll_stat;
       
convert_event:
    for (i=0; i<maxfd; i++) {
      w = &waiting_list[i];
      this = w->thread;
      if (this == NULL) continue;
      
      del = 0;
      if (FD_ISSET(i, &result_rfd)) {
        del = -1;
	this->ret = POLL_OK; 
      } else if (FD_ISSET(i, &result_wfd)) {
        del = -1;
        this->ret = POLL_OK;
      } else {
	if (timerisset(&w->timeout) && timercmp(&w->timeout, &current_time, <)) {
	  del = -1;
	  this->ret = POLL_TIMEOUT;
	}      
      }
      if (del) {
	poll_cnt[0 - this->ret]++;
	assert(this->state == PS_FD_WAIT);
	this->state = PS_READY;
	put_queue2(ready_queue, this);
	FD_CLR(i, &rfd);
	FD_CLR(i, &wfd);
	w->thread = NULL;
      }
    }
    collect_waiting_fd();    
    return poll_stat;
#else

    /* traditional poll event handle */

    if ((poll_stat = poll(waiting_fd, open_fd_cnt, 0)) < 0)
       return poll_stat;

convert_event:
    for (i=0; i<open_fd_cnt; i++) {
      w = &waiting_list[i];
      p =   &waiting_fd[i];
      this = w->thread;
      del = 0;
      if((revents = p->revents) == 0) {
	if (timerisset(&w->timeout) && timercmp(&w->timeout, &current_time, <)) {
	  del = -1;
	  this->ret = POLL_TIMEOUT;
	}
      }
      else if(revents & POLLHUP) {
	del = -1;
	cnt_hangup++;
	this->ret = POLL_HANGUP;
      }     
      else if(revents & POLLERR) {
	del = -1;
	this->ret = POLL_ERROR;
      }     
      else if(revents & POLLNVAL) {
	del = -1;
	this->ret = POLL_NVAL;
      }     
      else if(revents & (p->events)) {
	del = -1;
	this->ret = POLL_OK;
      }
      if (del) {

	poll_cnt[0 - this->ret]++;

	p->fd = -1;
	assert(this->state == PS_FD_WAIT);
	this->state = PS_READY;
	put_queue2(ready_queue, this);
      }
    }
    collect_waiting_fd();
    
    return poll_stat;
    
#endif
#endif


}


/* For each thread, we use hash table to manage open socket list. Because it is
   easier to delete and insert.

   We use a priority to maintain those tasks that are waiting for socket I/O.
   By using priority, it is possible to make the deadline first job to be scheduled
   as early as possible.
*/

static int yield_cnt = 0;

/* too large yield_threshold will make CPU unnecessary busy.
   But a small one may have penalty on performance.
   if your server performs bad, try to increase it.
 */
#ifdef _USE_FDM_LIBRARY
/* fdm_wait_event() running time is a lot shorter than plain poll()
   we need larger threshold to avoid performance penalty 
 */
static const int yield_threshold = 100;
#else
static const int yield_threshold = 50; 
#endif
static int sched_count=0;
static const int busy_sched = 100;

void scheduler(void)
{
  ethread *this;
  sched_count++;

#ifndef _USE_FDM_LIBRARY
//  if(sched_count > busy_sched) {
//    poll_fd();
//    sched_count = 0;
//  }
#endif  
  
  this = (ethread *) get_queue2(ready_queue);
  if (this) {
    yield_cnt = 0;
    assert(this->state == PS_READY);

    run_thread = this;
    this->state = PS_RUNNING;
    context_switch_to_thread();
  }
  else {  
    if(yield_cnt > yield_threshold) {
      usleep(500);
    }
    else
    {
      yield_cnt++;
      sched_yield();
    }
    
    poll_fd();
    sched_count = 0;
    empty_poll_times++;
  }
      

  /*  if (queue_size2(ready_queue)==0 && open_fd_cnt==0)
      PANIC("No ready job available and open fd\n");
  */
}

/* ===================================
               public routines
      =============================*/

int get_thread_ID(void)
{
  return run_thread->ID;
}

/* ===================================================================
 * ethread_exit()
 */

void ethread_exit(int status)
{
  /* Save return value */
  run_thread->ret = status;
  run_thread->state = PS_DEAD;
  
  /* This thread will never run again */
  assert(role == Role_thread);

  role = Role_thread_2_sys;

  dlinkDelete(& run_thread->active_link, &active_list);


  stack_check();  
  
  longjmp(sys_thread.machdep_state, 1);
}

/* ---------------------------------------- */
/* Section: Stack Analysis Code Declaration */                         /* Alex Wu, 2001/7/19 - 2001/7/20 */
/* ---------------------------------------- */
void do_stack_clean(char * file, int line)
{
   int i;
   char *ptr;
   char *ptr_end;
   int last_variable;
   
   ptr_end = (char *) ((&last_variable) + 1);
   ptr = (char *) run_thread->stack; 

   i = stksize - ((unsigned int) ptr_end - (unsigned int) ptr);
   fprintf(stderr, "%s: %i: Stack clean up, max is set from %i to %i\n", file, line, max_stack_usage, i);   
   max_stack_usage = i;
   
   for(i=0;i<stksize && (unsigned int) &ptr[i] < (unsigned int) ptr_end; i++)
   {     
      ptr[i] = 0;
   }
}

void do_stack_check(char * file, int line)
{
   int i;
   char *ptr;
   
   ptr = (char *) run_thread->stack; 
   for(i=0;i<stksize; i++)
   {
      if(ptr[i] != 0) break;
   }
   
   if(max_stack_usage < stksize - i) {
     fprintf(stderr, "%s: %i: Stack grow up, from %i to %i\n", file, line, max_stack_usage, stksize - i); 
     max_stack_usage = stksize - i;
   }        
}
/* --------- End Section ------------------ */


void thread_yield(void)
{
  run_thread->state = PS_READY;
  run_thread->lock = NULL;
  run_thread->fd = -1;
  put_queue2(ready_queue, run_thread);
  context_switch_to_sys();
}


jmp_buf tmp_buf;
int sleep_on_fd_do(int fd, int event_type, int msec_timeout)
{
#ifdef _USE_FDM_LIBRARY
  struct pollfd p;
  struct timeval timeout, *timeout_ptr;
#else  
#ifndef _RT_USE_SELECT
  struct pollfd *p;
#endif
  waiting_entry *w;
#endif  
  struct timeval time_tmp;  
  int ret;


  setjmp(tmp_buf);

  run_thread->fd = fd;
  run_thread->lock = NULL;
  run_thread->state = PS_FD_WAIT;

#ifdef _USE_FDM_LIBRARY
    p.events = event_type;
    p.fd = fd;
    run_thread->caller = *(((int **) tmp_buf[0].__jmpbuf[JB_BP])+1);


    if (msec_timeout)
    {
       timeout_ptr = &timeout;
       timerclear(timeout_ptr);
       time_tmp.tv_sec = msec_timeout / 1000;
       time_tmp.tv_usec = (msec_timeout % 1000) * 1000;
       timeradd(&current_time, &time_tmp, timeout_ptr);
    } else {
       timeout_ptr = NULL;
    }
    
    
    ret = fdm_update_fd_mode(&p, run_thread, timeout_ptr);
    assert(ret == 0);
#else
#ifdef _RT_USE_SELECT
    assert(fd < MAX_WAITING_LENGTH);
    w = &waiting_list[fd];
    
    switch (event_type) {
    case POLLIN:
	FD_SET(fd, &rfd);
	break;
    case POLLOUT:
    	FD_SET(fd, &wfd);
        break;
    }
    if (maxfd < fd+1)
    	maxfd = fd+1;
#else
    assert(open_fd_cnt < MAX_WAITING_LENGTH);
    w = &waiting_list[open_fd_cnt];
    p = &waiting_fd[open_fd_cnt];
    p->events = event_type;
    p->fd = fd;
    open_fd_cnt++;
#endif
  w->caller = *(((int **) tmp_buf[0].__jmpbuf[JB_BP])+1)    ;

  w->thread = run_thread;    

  timerclear(&w->timeout);
  if (msec_timeout)
  {
     time_tmp.tv_sec = msec_timeout / 1000;
     time_tmp.tv_usec = (msec_timeout % 1000) * 1000;
     timeradd(&current_time, &time_tmp, &w->timeout);
  }

#endif 

  ret = context_switch_to_sys();
  return ret;
}


/* ==========  eLock ============ */

int elock_ifnot_empty(elock * lock)
{
  return (lock->head != 0);
}

void elock_init(elock * lock)
{
  lock->head = lock->tail = 0;
}

elock *CREATE_elock()
{
  elock *lock = malloc(sizeof(elock));
  elock_init(lock);
  return lock;
}

int sleep_reg(const char * file, int line)
{
  run_thread->code_file = file;
  run_thread->code_line = line;
  run_thread->sleep_time = current_time;
  return 1;
}

int sleep_on_elock_do(elock *lock)
{
  run_thread->state = PS_WAIT_WAIT;
  run_thread->fd = -1;
  run_thread->lock = lock;
  dlinkAddTail(run_thread, &run_thread->link, lock);
  return context_switch_to_sys();
}


void wake_up_elock(elock *lock)
{
  ethread *this;
  if (elock_ifnot_empty(lock)) {
    this = lock->tail->data;
    dlinkDelete(&this->link, lock);
    this->state = PS_READY;
    this->ret = ELOCK_OK;
    put_queue2(ready_queue, this);
  }
}



/* ----------- temp use for debug purpose ---------- */


static void travel_queue2(queue_t *qu, int para, void(*action)(ethread *, int))
{
   ethread *this;
   this = (ethread *) ((queue2_t *)qu)->Queue.head->data;
   while(this != NULL)
   {
      action(this, para);
      this = (ethread *) this->link.next->data;
   }
}

static void put_queue2(queue_t *qu, ethread *this)
{
  queue2_t * q2 = (queue2_t *) qu;
  
  dlinkAddTail(this, & this->link, & q2->Queue);
  q2->NumInQueue++;
}

static void *get_queue2(queue_t *qu)
{
  ethread *this;
  queue2_t * q2 = (queue2_t *) qu;

  if (q2->NumInQueue==0)
    return 0;
  q2->NumInQueue--;

  this = (ethread *) q2->Queue.head->data;
  dlinkDelete(& this->link, & q2->Queue);
  
  return (void *) this;
}

static int queue_size2(queue_t *qu)
{
  return ((queue2_t *)qu)->NumInQueue;
}

static queue_t *init_queue2()
{
  queue2_t *qu;

  qu = (queue2_t *) malloc(sizeof(queue2_t));
  assert(qu != NULL);
  qu->NumInQueue=0;
  dlink_list_init(& qu->Queue);

  return (queue_t *) qu;
}
