#ifndef DATA_STRUCT_H
#define DATA_STRUCT_H
#include <malloc.h>
#include <sys/types.h>
#include <regex.h>

typedef struct _wordlist {
    char *key;
    struct _wordlist *next;
}wordlist;

typedef struct _dlink_node {
    void *data;
    struct _dlink_node *prev;
    struct _dlink_node *next;
}dlink_node;

typedef struct _dlink_list {
    dlink_node *head;
    dlink_node *tail;
  int cnt;
}dlink_list;

typedef struct _intlist {
    int i;
    struct _intlist *next;
}intlist;

typedef struct _intrange {
    int i;
    int j;
    struct _intrange *next;
}intrange;
 
typedef struct _ushortlist {
    u_short i;
    struct _ushortlist *next;
}ushortlist;
 

void intlistDestroy(intlist ** list);

int dlink_ifnot_empty(dlink_list * list);
int dlink_listCount(dlink_list * list);
void data_struct_init(void);
void dlinkAdd(void *data, dlink_node * m, dlink_list * list);
void dlinkAddTail(void *data, dlink_node * m, dlink_list * list);
void dlinkDelete(dlink_node * m, dlink_list * list);
void dlink_list_init(dlink_list * list);
void wordlistAddWl(wordlist ** list, wordlist * wl);
void wordlistCat(const wordlist * w, char * mb);
void wordlistDestroy(wordlist ** list);
void wordlistJoin(wordlist ** list, wordlist ** wl);
wordlist * wordlistDup(const wordlist * w);

#endif
