#include "data_struct.h"
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>
#ifndef __USE_GNU
 #define __USE_GNU
 #include <fcntl.h>
 #undef __USE_GNU
#else
 #include <fcntl.h>
#endif
#include <string.h>
#include <sys/poll.h>
#include <assert.h>
#include <signal.h>
#include <sched.h>
#include <stdio.h>
#include <errno.h>
#include "callback.h"



static int msgsize = STD_MESSAGE_SIZE, port = STD_SERVER_PORT;
queue_t *ready_queue;
callback_t *run_callback;
struct timeval t1, t2;
struct timeval current_time;
int abort_server = 0;
int callback_id_global;

int open_fd_cnt;
struct pollfd waiting_fd[MAX_WAITING_LENGTH];
waiting_entry waiting_list[MAX_WAITING_LENGTH];

static unsigned int poll_cnt[1 - POLL_ABORT];
static char * poll_str[1 - POLL_ABORT] = {
  "OK",
  "INVALID",
  "HANGUP",
  "ERROR",
  "TIMEOUT",
  "ABORT" 
};
static unsigned int poll_times = 0;
static unsigned int empty_poll_times = 0;

// CB FUNCTION
int clear_connection();
int getreq();
int send_response();
int acceptor();


static void put_queue2(queue_t *qu, callback_t *this)
{
  queue2_t * q2 = (queue2_t *) qu;
  
  dlinkAddTail(this, & this->link, & q2->Queue);
  q2->NumInQueue++;
}

static void *get_queue2(queue_t *qu)
{
  callback_t *this;
  queue2_t * q2 = (queue2_t *) qu;

  if (q2->NumInQueue==0)
    return 0;
  q2->NumInQueue--;

  this = (callback_t *) q2->Queue.head->data;
  dlinkDelete(& this->link, & q2->Queue);
  
  return (void *) this;
}

static queue_t *init_queue2()
{
  queue2_t *qu;

  qu = (queue2_t *) malloc(sizeof(queue2_t));
  assert(qu != NULL);
  qu->NumInQueue=0;
  dlink_list_init(& qu->Queue);

  return (queue_t *) qu;
}

int sleep_reg(const char * file, int line)
{
  run_callback->code_file = file;
  run_callback->code_line = line;
  run_callback->sleep_time = current_time;
  return 1;
}

int sleep_on_fd_do(int event_type, int msec_timeout)
{
  struct pollfd *p;
  waiting_entry *w;
  struct timeval time_tmp;  

  assert(run_callback->state == PS_RUNNING);
  assert(open_fd_cnt < MAX_WAITING_LENGTH);
  
  run_callback->state = PS_FD_WAIT;    
  w = &waiting_list[open_fd_cnt];
  p = &waiting_fd[open_fd_cnt];
  p->events = event_type;
  p->fd = run_callback->fd;
  open_fd_cnt++;

  w->cb = run_callback;

  timerclear(&w->timeout);
  if (msec_timeout)
  {
     time_tmp.tv_sec = msec_timeout / 1000;
     time_tmp.tv_usec = (msec_timeout % 1000) * 1000;
     timeradd(&current_time, &time_tmp, &w->timeout);
  }

  return 0;
}

static void collect_waiting_fd(void)
{
  int i,cnt=0;
  struct pollfd *of, *nf;
  waiting_entry *ot,*nt;

  of = nf = &waiting_fd[0];
  ot = nt = &waiting_list[0];
  for (i = 0; i < open_fd_cnt; i++, of++, ot++)
    if (of->fd > 0) {
      if (nf!=of) {
        *nf = *of;
        *nt = *ot;
      }
      cnt++;
      nf++; nt++;
    }
  open_fd_cnt = cnt;
}


int cnt_hangup = 0;

static int poll_fd(void)
{
    int i,revents;
    int del;
    int poll_stat;
    struct pollfd *p;
    waiting_entry *w;
    callback_t *this;

    poll_times++;

    if (open_fd_cnt==0) {
      return 0;
    } 

    for (i=0; i<open_fd_cnt; i++) {
      waiting_fd[i].revents = 0;
    }

    /* traditional poll event handle */

    if ((poll_stat = poll(waiting_fd, open_fd_cnt, 0)) < 0)
       return poll_stat;

    for (i=0; i<open_fd_cnt; i++) {
      w = &waiting_list[i];
      p =   &waiting_fd[i];
      this = w->cb;
      del = 0;
      if((revents = p->revents) == 0) {
	if (timerisset(&w->timeout) && timercmp(&w->timeout, &current_time, <)) {
	  del = -1;
	  this->ret = POLL_TIMEOUT;
	}
      }
      else if(revents & POLLHUP) {
	del = -1;
	cnt_hangup++;
	this->ret = POLL_HANGUP;
      }     
      else if(revents & POLLERR) {
	del = -1;
	this->ret = POLL_ERROR;
      }     
      else if(revents & POLLNVAL) {
	del = -1;
	this->ret = POLL_NVAL;
      }     
      else if(revents & (p->events)) {
	del = -1;
	this->ret = POLL_OK;
      }
      if (del) {

	poll_cnt[0 - this->ret]++;

	p->fd = -1;
	assert(this->state == PS_FD_WAIT);
	this->state = PS_READY;
	put_queue2(ready_queue, this);
      }
    }
    collect_waiting_fd();
    
    return poll_stat;

}



static int yield_cnt = 0;
static const int yield_threshold = 50; 
static int sched_count=0;

void scheduler(void)
{
  callback_t *this;
  int ret;
  
  sched_count++;
  this = (callback_t *) get_queue2(ready_queue);
  if (this) {
    assert(this->state == PS_READY);  

    yield_cnt = 0;
    run_callback = this;
    this->state = PS_RUNNING;

    /* callback function calls here */
    while (run_callback != NULL && run_callback->state == PS_RUNNING) {
	    switch (this->cb_state) {
	    case CB_GETREQ:
	    	ret = getreq();
	    	break;
	    case CB_REPLY:
	    	ret = send_response();
    		break;
	    case CB_HANGUP:
	    	ret = clear_connection();
	    	break;
	    case CB_ACCEPT: 
	    	ret = acceptor();
	    	break;   
	    default:
	    	assert(0);
	    }
    }	    
  }
  else {  
    if(yield_cnt > yield_threshold) {
      usleep(500);
    }
    else
    {
      yield_cnt++;
      sched_yield();
    }
    
    poll_fd();
    sched_count = 0;
    empty_poll_times++;
  }
}


time_t getCurrentTime(void) 
{
#if GETTIMEOFDAY_NO_TZP
  gettimeofday(&current_time);
#else
  gettimeofday(&current_time, NULL);
#endif

  return current_time.tv_sec;
}                                                                               



int cb_create(int cb_state, int fd) {
	callback_t *cb;
	
	cb = (callback_t *)malloc(sizeof(callback_t));
	
	if (cb) {
	        cb->ID = callback_id_global++;
    
	        // callback id wrapping
                if (callback_id_global >= 999999) 
                	callback_id_global = 0;
	
	
		cb->state = PS_READY;
		cb->getin_time = getCurrentTime();
		cb->fd = fd;
		cb->cb_state = cb_state;

	        put_queue2(ready_queue, (void *) cb);
	        return(cb->ID);
	}
	
	perror("No space available for callback\n");
	return(-1);

}


int cb_exit(callback_t *cb) {
	free(cb);
	return 0;
}



void callback_init(void)
{
  int i;


  for(i=0; i<= 0 - POLL_ABORT; i++) {
    poll_cnt[i] = 0;
  }

  /* Initialize the first thread */
  ready_queue = (queue_t *) init_queue2();

  callback_id_global = 0;
  run_callback = NULL;

}


int open_socket(int domain, int type, int protocol)
{
	int sfd = socket(domain, type, protocol),
	flags = 1;

	if (sfd == -1)return -1;

	if (ioctl(sfd, FIONBIO, &flags) &&
			((flags = fcntl(sfd, F_GETFL, 0)) < 0 ||
			fcntl(sfd, F_SETFL, flags | O_NONBLOCK) < 0)) {
		close(sfd);
		return -1;
	}

	return sfd;
}


void usage(char const *prgname)
{
	fprintf(stderr,"use: %s [--msgsize nbytes (%d)] [--port nbr (%d)]\n", prgname, msgsize, port);
}


int _read(int conn, char *buf, int nbyte)
{
	int n;

again:
	if ((n = read(conn, buf, nbyte)) < 0) {
		if (errno == EINTR)
			goto again;
		if ((errno != EAGAIN) && (errno != EWOULDBLOCK))
			return -1;
		return -2;
	}
	return n;
}


int _write(int conn, char const *buf, int nbyte)
{
	int n;

again2:
	if ((n = write(conn, buf, nbyte)) < 0) {
		if (errno == EINTR)
			goto again2;
		if ((errno != EAGAIN) && (errno != EWOULDBLOCK))
			return -1;
		return -2;
	}
	assert (n == nbyte);
	return n;
}


/* return -1 means real ERROR occurs. this function exclude EAGAIN.., etc */
int _accept(int conn, struct sockaddr *addr, int *addrlen)
{
	int sfd, flags = 1;

again3:
	if ((sfd = accept(conn, addr, (socklen_t *) addrlen)) < 0) {
		if (errno == EINTR)
			goto again3;
		if ((errno != EAGAIN) && (errno != EWOULDBLOCK))
			return -1;
		return -2;
	}

	if (ioctl(sfd, FIONBIO, &flags) &&
			((flags = fcntl(sfd, F_GETFL, 0)) < 0 ||
			fcntl(sfd, F_SETFL, flags | O_NONBLOCK) < 0)) {
		close(sfd);
		return -1;
	}
	return sfd;
}


static int read_data(int conn, int *rindex, int *nbytes, char buffer[])
{
	int nb;

	if (*rindex > (DATA_BUFFER_SIZE - MIN_AHEAD_SPACE)) {
		memcpy(buffer, buffer + *rindex, *nbytes - *rindex);
		*nbytes = *nbytes - *rindex;
		*rindex = 0;
	} else if (*nbytes == DATA_BUFFER_SIZE && *rindex > 0) {
		if (*rindex > (DATA_BUFFER_SIZE >> 1))
			memcpy(buffer, buffer + *rindex, *nbytes - *rindex);
		else
			memmove(buffer, buffer + *rindex, *nbytes - *rindex);
		*nbytes = *nbytes - *rindex;
		*rindex = 0;
	}

	nb = _read(conn, buffer + *rindex, DATA_BUFFER_SIZE - *rindex);
	if (nb == -2) return -2;
	if (nb <= 0)
		return -1;

	*nbytes += nb;

	return 0;
}


static char *read_line(int conn, int *rindex, int *nbytes, char buffer[])
{
	char *nline = NULL;
	int ret;

	for ( ;!nline; ) {
		if (*nbytes > *rindex) {
			if ((nline = memchr(buffer + *rindex, '\n', *nbytes - *rindex))) {
				char *line = buffer + *rindex;

				*rindex += (nline - line) + 1;
				for (; nline > line && nline[-1] == '\r'; nline--);
				*nline = '\0';
				return line;
			}
			if (*nbytes == DATA_BUFFER_SIZE)
				return NULL;
		}
		
		ret = read_data(conn, rindex, nbytes, buffer);

		if (ret == -2)
			return (char *)-2;
		if (ret < 0)
			return NULL;
	}

	return NULL;
}


static int parse_request(int conn, int *rindex, int *nbytes, int *rl ,char buffer[])
{
	char *line;

	if (*rl == 0) {
		line = read_line(conn, rindex, nbytes, buffer);
		if ((int)line == -2)
			return -2;
		if ((int)line == 0)
			return -1;
//		printf("line: %s\n", line);
		*rl = 1;
	}


	for (;;) {
		line = read_line(conn, rindex, nbytes, buffer);
		if ((int)line == -2)
			return -2;
		if ((int)line == 0)
			return -1;
//		printf("line: %s\n", line);			
		if (*line == '\0') {
			*rl = 0;
			break;
		}
	}
	return 0;
}


// CB POINT
int clear_connection() {
//	printf("conn %d closed!\n", run_callback->fd);
	close(run_callback->fd);
	cb_exit(run_callback);
	run_callback = NULL;
	
	return 0;
}


// CB POINT
int send_response()
{
	static int resplen = -1;
	static char *resp = NULL;
	int ret;

	if (resp == NULL) {
		msgsize = ((msgsize + 63) / 64) * 64;

		resp = (char *) malloc(msgsize + 256);

		sprintf(resp,
				"HTTP/1.1 200 OK\r\n"
				"Server: dp server\r\n"
				"Content-Type: text/plain\r\n"
				"Content-Length: %d\r\n"
				"\r\n", msgsize);

		while (msgsize > 0) {
			strcat(resp, "01234567890123\r\n" "01234567890123\r\n" "01234567890123\r\n" "01234567890123\r\n");
			msgsize -= 64;
		}

		resplen = strlen(resp);
	}

	ret = _write(run_callback->fd, resp, resplen);
	if (ret == -2) {
		sleep_on_fd(POLLOUT, 1000);
		return -2;
	}
	
	if (ret == -1) {
		perror("send_response error!\n");
	}
	run_callback->cb_state = CB_GETREQ;	

	return 0;
}


// CB POINT
int getreq() {
	int ret;

	ret = parse_request(run_callback->fd, 
			    &(run_callback->nbytes), 
                            &(run_callback->rindex), 
                            &(run_callback->read_a_line),
 	                    run_callback->buffer);

	if (ret == -1) {
		/* close connection */
		run_callback->cb_state = CB_HANGUP;
	}              
	if (ret == 0) {
		/* ok! we've get a complete request */
		run_callback->cb_state = CB_REPLY;
	}
	if (ret == -2) {
		sleep_on_fd(POLLIN, 1000);
	}
	
	return ret;
}


// CB POINT
int acceptor()
{
	int conn_socket = run_callback->fd;
	struct sockaddr_in addr;
	int ret, sfd, addrlen = sizeof(addr);

	while ((sfd = _accept(conn_socket, (struct sockaddr *) &addr, &addrlen)) > 0) {
		ret = cb_create(CB_GETREQ, sfd);
//		printf("accept conn %d\n", sfd);
		if (ret < 0) {
			close(sfd);
			exit(EXIT_FAILURE);
		}

	}
	if (sfd == -1) {
		perror("accept critical error!");
		exit(EXIT_FAILURE);
	}
	sleep_on_fd(POLLIN, 1000);

	return sfd;
}


void timerec(int val) {
	abort_server = 1;  
}


int main(int argc, char *argv[]) {

	int ii, ret, sfd, flags = 1;
	struct linger ling = {0, 0};
	struct sockaddr_in addr;
	struct rusage r;
	float p;
	long etime, utime, stime;


	for (ii = 1; ii < argc; ii++) {
		if (strcmp(argv[ii], "--msgsize") == 0) {
			if (++ii < argc)
				msgsize = atoi(argv[ii]);
			continue;
		}
		if (strcmp(argv[ii], "--port") == 0) {
			if (++ii < argc)
				port = atoi(argv[ii]);
			continue;
		}

		usage(argv[0]);
		return -1;
	}

	gettimeofday(&t1, NULL);	
	signal(SIGINT, timerec);
	
	callback_init();

	if ((sfd = open_socket(AF_INET, SOCK_STREAM, 0)) == -1) {	
		perror("listen socket open fail!");
		return -1;
	}

	setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &flags, sizeof(flags));
	setsockopt(sfd, SOL_SOCKET, SO_KEEPALIVE, &flags, sizeof(flags));
	setsockopt(sfd, SOL_SOCKET, SO_LINGER, &ling, sizeof(ling));

	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	if (bind(sfd, (struct sockaddr *) &addr, sizeof(addr)) == -1) {
		close(sfd);
		return -1;
	}

	listen(sfd, 128);
	
	
	ret = cb_create(CB_ACCEPT, sfd);
	if (ret < 0) return -1;

	while (!abort_server) {
		getCurrentTime();
		scheduler();
	}

	/* report user time, system time and CPU usage */

	gettimeofday(&t2, NULL);
	getrusage(RUSAGE_SELF, &r);

	etime = (t2.tv_sec - t1.tv_sec)*SEC_TO_USEC+(t2.tv_usec-t1.tv_usec);
	utime = r.ru_utime.tv_sec*SEC_TO_USEC+r.ru_utime.tv_usec;
	stime = r.ru_stime.tv_sec*SEC_TO_USEC+r.ru_stime.tv_usec;
        printf("user time = %ld\n", utime);
        printf("system time = %ld\n", stime);
        printf("elapsed time = %ld\n", etime);
	p = (float) (utime + stime) / etime;
	printf("cpu usage = %f\n", p*100);

	return 0;
}
