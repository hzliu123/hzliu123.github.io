#ifndef _ETHREAD_H_
#define	_ETHREAD_H_

#include <errno.h>
#include <setjmp.h> 
#include <stdio.h>


#define OK  0
#define NOTOK -1

#define MIN_STACK_SZ 20480


typedef enum {
  POLL_OK = 0,
  POLL_NVAL = -1,
  POLL_HANGUP = -2,
  POLL_ERROR = -3,
  POLL_TIMEOUT = -4,
  POLL_ABORT = -5
} POLL_code;

typedef enum {
  ELOCK_OK = 0,
  ELOCK_ABORT = 1
} ELOCK_code;


enum ethread_state {
  PS_SYSTEM,
  PS_RUNNING,
  PS_FD_WAIT,
  PS_WAIT_WAIT,
  PS_READY,
  PS_DEAD,
  PS_MAX
};

/* struct machdep_pthread {
 };
*/

typedef dlink_list elock;

typedef struct _ethread {
  enum ethread_state	state;
  int ID;
  int	fd;			/* Used when thread waiting on fd */
  elock * lock;                 /* Used when thread waiting on elock */
  int   stacksize;
  int   ret;            // return status
  void *stack;
  time_t	getin_time;
  time_t	time;

  // for system thread debug
  struct timeval sleep_time;
  int code_line;
  const char * code_file;

  void                        *(*start_routine)(void *);
  void                        *start_argument;
  jmp_buf                     machdep_state;
  int err_num;
  dlink_node link;
  dlink_node active_link;
#ifdef _USE_FDM_LIBRARY
  void *caller;
#endif
} ethread;

#ifndef _USE_FDM_LIBRARY
typedef struct _waiting_entry {
  struct timeval timeout;
  ethread *thread;
  void *caller;
} waiting_entry;
#endif

/*
 * Globals
 */
 
typedef struct {
  int NumInQueue;
  dlink_list Queue;
} queue2_t;

typedef queue2_t queue_t;
 
extern  ethread	 *ethread_run;
extern	queue_t  *ready_queue;

#ifndef ETHREAD_IMP
extern int context_switch;
#endif

/* public functions */
elock *CREATE_elock();
int elock_ifnot_empty(elock * lock);
int ethread_create(void * (*start_routine)(void *), void *arg);
int ethread_system_is_empty(void);
int get_thread_ID(void);
int sleep_reg(const char * file, int line);
#define sleep_on_elock(lock) (sleep_reg(__FILE__, __LINE__) ? sleep_on_elock_do(lock) :0)
int sleep_on_elock_do(elock *lock);
#define sleep_on_fd(fd, et, ms) (sleep_reg(__FILE__, __LINE__) ? sleep_on_fd_do(fd, et, ms) :0)
int sleep_on_fd_do(int fd, int event_type, int msec_timeout);
void ethread_init(void);
void ethread_shutdown(void);
void elock_init(elock * lock);
void ethread_exit(int status);
void print_ethread(ethread *A);
void scheduler(void);
void thread_yield(void);
void wake_up_elock(elock *lock);
time_t getCurrentTime(void);

/* Section:   Stack Analysis Code Definition */                     /* Alex Wu, from 2001/7/19 - 2001/7/20 */
void do_stack_check(char *file, int line);
void do_stack_clean(char *file, int line);

#ifdef DO_STACK_ANALYSIS
  #define stack_check() do_stack_check(__FILE__, __LINE__)
  #define stack_clean() do_stack_clean(__FILE__, __LINE__)
#else
  #define stack_check()
  #define stack_clean()
#endif
/* End Section: Stack Analysis Code Definition */

#endif
