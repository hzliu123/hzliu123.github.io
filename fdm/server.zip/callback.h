#ifndef CALLBACK_H
#define CALLBACK_H

#define STD_MESSAGE_SIZE		128
#define STD_SERVER_PORT			8080
#define DATA_BUFFER_SIZE		2048
#define MIN_AHEAD_SPACE			(DATA_BUFFER_SIZE / 12)
#define SEC_TO_USEC 1000000
#define MAX_WAITING_LENGTH 8192

enum {
  CB_ACCEPT,
  CB_GETREQ,
  CB_REPLY,
  CB_HANGUP
};

enum ethread_state {
  PS_SYSTEM,
  PS_RUNNING,
  PS_FD_WAIT,
  PS_WAIT_WAIT,
  PS_READY,
  PS_DEAD,
  PS_MAX
};

typedef enum {
  POLL_OK = 0,
  POLL_NVAL = -1,
  POLL_HANGUP = -2,
  POLL_ERROR = -3,
  POLL_TIMEOUT = -4,
  POLL_ABORT = -5
} POLL_code;

typedef struct {
  int ID;
  int state;		/* state related ready queue */
  int ret;		/* poll result */
  int fd;
  int cb_state;		/* which callback function will be called */
  time_t getin_time;
  
  int nbytes;		/* num of bytes read and keep in buffer */
  int rindex;		/* mark right most index of line break */
  int read_a_line;	/* boolean: a line is read? */
  char buffer[DATA_BUFFER_SIZE];
  dlink_node link;

  // for system thread debug
  struct timeval sleep_time;
  int code_line;
  const char * code_file;
} callback_t;

typedef struct _waiting_entry {
  struct timeval timeout;
  callback_t *cb;
} waiting_entry;

typedef struct {
  int NumInQueue;
  dlink_list Queue;
} queue2_t;

typedef queue2_t queue_t;

#define sleep_on_fd(et, ms) (sleep_reg(__FILE__, __LINE__) ? sleep_on_fd_do(et, ms) :0)



#endif
