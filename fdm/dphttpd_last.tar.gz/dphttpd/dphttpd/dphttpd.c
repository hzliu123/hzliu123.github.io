/*
 *	dphttpd - a simple server implementation to test event polling methods
 *
 *	07-01-2001	by Davide Libenzi <davidel@xmailserver.org>
 *
 */

/* this is stupid to say but anly one of these must be defined */

/* #define _USE_EVENTPOLL */

/* #define _USE_STDPOLL */

/* #define _USE_DEVPOLL */

#define _USE_RTSIGNALS
/*
#define _USE_ONESIG
#define F_LINUX_SPECIFIC_BASE	1024
#define F_SETAUXFL	(F_LINUX_SPECIFIC_BASE+3)
#define O_ONESIGFD	(2<<17)
*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <unistd.h>
#ifndef __USE_GNU
 #define __USE_GNU
 #include <fcntl.h>
 #undef __USE_GNU
#else
 #include <fcntl.h>
#endif
#include <stdarg.h>
#include <string.h>
#include <assert.h>
#include <limits.h>
#include <ctype.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sched.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <netdb.h>
#include <syslog.h>
#include <glob.h>
#include <semaphore.h>
#include <coro.h>



#if defined(_USE_STDPOLL) || defined(_USE_RTSIGNALS)
#include <sys/poll.h>
#endif	/* #if defined(_USE_STDPOLL) || defined(_USE_RTSIGNALS) */


#if defined(_USE_EVENTPOLL)
#include <asm/page.h>
#include <asm/poll.h>
#include <linux/eventpoll.h>
#endif

#if defined(_USE_DEVPOLL)
#include <asm/page.h>
#include <asm/poll.h>
#include <linux/devpoll.h>
#endif

#include "dbllist.h"




#define CO_STD_STACK_SIZE		4096
#define STD_SCHED_TIMEOUT		1
#define STD_LISTEN_SIZE			128
#define DATA_BUFFER_SIZE		2048
#define MIN_AHEAD_SPACE			(DATA_BUFFER_SIZE / 12)
#define STD_MESSAGE_SIZE		128
#define STD_SERVER_PORT			8080
#define MAX_DEFAULT_FDS			20000



struct dph_conn {
	struct list_head lnk;
	int sfd;
	int events, revents;
	struct coroutine *co;
	char buffer[DATA_BUFFER_SIZE];
	int nbytes, rindex;
};


#if defined(_USE_EVENTPOLL) || defined(_USE_DEVPOLL)
static int kdpfd;
static char *map;
#endif	/* #if defined(_USE_EVENTPOLL) || defined(_USE_DEVPOLL) */

#if defined(_USE_STDPOLL) || defined(_USE_RTSIGNALS)
struct pollfd *pfds;
#endif	/* #if defined(_USE_STDPOLL) || defined(_USE_RTSIGNALS) */

static int maxfds, numfds = 0;
static int chash_size;
static struct list_head *chash;
static int msgsize = STD_MESSAGE_SIZE, port = STD_SERVER_PORT,
		maxsfd = MAX_DEFAULT_FDS, stksize = CO_STD_STACK_SIZE;
#if defined(_USE_RTSIGNALS)
static int rtsig;
#endif	/* #if defined(_USE_RTSIGNALS) */


int dph_socket(int domain, int type, int protocol)
{
	int sfd = socket(domain, type, protocol),
		flags = 1;

	if (sfd == -1)
		return -1;
#if defined(_USE_RTSIGNALS)
	if ((flags = fcntl(sfd, F_GETFL, 0)) < 0 ||
			fcntl(sfd, F_SETFL, flags | O_NONBLOCK | O_ASYNC) < 0) {
		close(sfd);
		return -1;
	}
	fcntl(sfd, F_SETSIG, rtsig);
	fcntl(sfd, F_SETOWN, getpid());
#if defined(_USE_ONESIG)
	fcntl(sfd, F_SETAUXFL, O_ONESIGFD);
#endif	/* #if defined(_USE_ONESIG) */
#else	/* #if defined(_USE_RTSIGNALS) */
	if (ioctl(sfd, FIONBIO, &flags) &&
			((flags = fcntl(sfd, F_GETFL, 0)) < 0 ||
			fcntl(sfd, F_SETFL, flags | O_NONBLOCK) < 0)) {
		close(sfd);
		return -1;
	}
#endif	/* #if defined(_USE_RTSIGNALS) */
	return sfd;
}


int dph_close(int sfd)
{

	close(sfd);
	return 0;
}


int dph_connect(struct dph_conn *conn, const struct sockaddr *serv_addr, socklen_t addrlen)
{
	while (connect(conn->sfd, serv_addr, addrlen) == -1) {
		if (errno == EINTR)
			continue;
		if ((errno != EAGAIN) && (errno != EWOULDBLOCK))
			return -1;
		conn->events = POLLOUT | POLLERR | POLLHUP;
		co_resume(conn);
	}
	return 0;
}


int dph_read(struct dph_conn *conn, char *buf, int nbyte)
{
	int n;

	while ((n = read(conn->sfd, buf, nbyte)) < 0) {
		if (errno == EINTR)
			continue;
		if ((errno != EAGAIN) && (errno != EWOULDBLOCK))
			return -1;
		conn->events = POLLIN | POLLERR | POLLHUP;
		co_resume(conn);
	}
	return n;
}


int dph_write(struct dph_conn *conn, char const *buf, int nbyte)
{
	int n;

	while ((n = write(conn->sfd, buf, nbyte)) < 0) {
		if (errno == EINTR)
			continue;
		if ((errno != EAGAIN) && (errno != EWOULDBLOCK))
			return -1;
		conn->events = POLLOUT | POLLERR | POLLHUP;
		co_resume(conn);
	}
	return n;
}


int dph_accept(struct dph_conn *conn, struct sockaddr *addr, int *addrlen)
{
	int sfd, flags = 1;

	while ((sfd = accept(conn->sfd, addr, (socklen_t *) addrlen)) < 0) {
		if (errno == EINTR)
			continue;
		if ((errno != EAGAIN) && (errno != EWOULDBLOCK))
			return -1;
		conn->events = POLLIN | POLLERR | POLLHUP;
		co_resume(conn);
	}
#if defined(_USE_RTSIGNALS)
	if ((flags = fcntl(sfd, F_GETFL, 0)) < 0 ||
			fcntl(sfd, F_SETFL, flags | O_NONBLOCK | O_ASYNC) < 0) {
		close(sfd);
		return -1;
	}
	fcntl(sfd, F_SETSIG, rtsig);
	fcntl(sfd, F_SETOWN, getpid());
#if defined(_USE_ONESIG)
	fcntl(sfd, F_SETAUXFL, O_ONESIGFD);
#endif	/* #if defined(_USE_ONESIG) */
#else	/* #if defined(_USE_RTSIGNALS) */
	if (ioctl(sfd, FIONBIO, &flags) &&
			((flags = fcntl(sfd, F_GETFL, 0)) < 0 ||
			fcntl(sfd, F_SETFL, flags | O_NONBLOCK) < 0)) {
		close(sfd);
		return -1;
	}
#endif	/* #if defined(_USE_RTSIGNALS) */
	return sfd;
}


static int dph_new_conn(int sfd, void *func)
{
	struct dph_conn *conn = (struct dph_conn *) malloc(sizeof(struct dph_conn));
#if defined(_USE_EVENTPOLL) || defined(_USE_DEVPOLL)
	struct pollfd pfd;
#endif	/* #if defined(_USE_EVENTPOLL) || defined(_USE_DEVPOLL) */

	if (!conn)
		return -1;

	memset(conn, 0, sizeof(*conn));
	DBL_INIT_LIST_HEAD(&conn->lnk);
	conn->sfd = sfd;
	conn->events = POLLIN | POLLOUT | POLLERR | POLLHUP;
	conn->revents = 0;
	conn->nbytes = conn->rindex = 0;
	if (!(conn->co = co_create(func, NULL, stksize))) {
		free(conn);
		return -1;
	}

	DBL_LIST_ADDT(&conn->lnk, &chash[sfd % chash_size]);

#if defined(_USE_EVENTPOLL) || defined(_USE_DEVPOLL)
	pfd.fd = sfd;
	pfd.events = POLLIN | POLLOUT | POLLERR | POLLHUP;
	pfd.revents = 0;
	if (write(kdpfd, &pfd, sizeof(pfd)) != sizeof(pfd)) {
		fprintf(stderr, "poll set insertion error: fd=%d\n", sfd);

		DBL_LIST_DEL(&conn->lnk);
		co_delete(conn->co);
		free(conn);
		return -1;
	}
#endif	/* #if defined(_USE_EVENTPOLL) || defined(_USE_DEVPOLL) */

	++numfds;

	co_call(conn->co, conn);

	return 0;
}


static void dph_exit_conn(struct dph_conn *conn)
{
#if defined(_USE_EVENTPOLL) || defined(_USE_DEVPOLL)
	struct pollfd pfd;
#endif	/* #if defined(_USE_EVENTPOLL) || defined(_USE_DEVPOLL) */

#if defined(_USE_EVENTPOLL) || defined(_USE_DEVPOLL)
	pfd.fd = conn->sfd;
	pfd.events = POLLREMOVE;
	pfd.revents = 0;
	if (write(kdpfd, &pfd, sizeof(pfd)) != sizeof(pfd)) {
		fprintf(stderr, "poll set deletion error: fd=%d\n", conn->sfd);

	}
#endif	/* #if defined(_USE_EVENTPOLL) || defined(_USE_DEVPOLL) */

	DBL_LIST_DEL(&conn->lnk);
	dph_close(conn->sfd);
	free(conn);

	--numfds;

	co_exit(0);
}


static int dph_read_data(struct dph_conn *conn)
{
	int nbytes;

	if (conn->rindex > (sizeof(conn->buffer) - MIN_AHEAD_SPACE)) {
		memcpy(conn->buffer, conn->buffer + conn->rindex, conn->nbytes - conn->rindex);
		conn->nbytes = conn->nbytes - conn->rindex;
		conn->rindex = 0;
	} else if (conn->nbytes == sizeof(conn->buffer) && conn->rindex > 0) {
		if (conn->rindex > (sizeof(conn->buffer) >> 1))
			memcpy(conn->buffer, conn->buffer + conn->rindex, conn->nbytes - conn->rindex);
		else
			memmove(conn->buffer, conn->buffer + conn->rindex, conn->nbytes - conn->rindex);
		conn->nbytes = conn->nbytes - conn->rindex;
		conn->rindex = 0;
	}

	if ((nbytes = dph_read(conn, conn->buffer + conn->rindex,
			sizeof(conn->buffer) - conn->rindex)) <= 0)
		return -1;

	conn->nbytes += nbytes;

	return 0;
}


static char *dph_read_line(struct dph_conn *conn)
{
	char *nline = NULL;

	for (; !nline;) {
		if (conn->nbytes > conn->rindex) {
			if ((nline = memchr(conn->buffer + conn->rindex, '\n', conn->nbytes - conn->rindex))) {
				char *line = conn->buffer + conn->rindex;

				conn->rindex += (nline - line) + 1;
				for (; nline > line && nline[-1] == '\r'; nline--);
				*nline = '\0';
				return line;
			}
			if (conn->nbytes == sizeof(conn->buffer))
				break;
		}
		if (dph_read_data(conn) < 0)
			break;
	}
	return NULL;
}


static int dph_parse_request(struct dph_conn *conn)
{
	char *line;

	if (!(line = dph_read_line(conn)))
		return -1;


	for (;;) {
		if (!(line = dph_read_line(conn)))
			return -1;
		if (*line == '\0')
			break;


	}
	return 0;
}


static int dph_send_response(struct dph_conn *conn)
{
	static int resplen = -1;
	static char *resp = NULL;

	if (resp == NULL) {
		msgsize = ((msgsize + 63) / 64) * 64;

		resp = (char *) malloc(msgsize + 256);

		sprintf(resp,
				"HTTP/1.1 200 OK\r\n"
				"Server: dp server\r\n"
				"Content-Type: text/plain\r\n"
				"Content-Length: %d\r\n"
				"\r\n", msgsize);

		while (msgsize > 0) {
			strcat(resp, "01234567890123\r\n" "01234567890123\r\n" "01234567890123\r\n" "01234567890123\r\n");
			msgsize -= 64;
		}

		resplen = strlen(resp);
	}

	dph_write(conn, resp, resplen);

	return 0;
}


static void *dph_httpd(void *data)
{
	struct dph_conn *conn = (struct dph_conn *) data;

	while (dph_parse_request(conn) == 0) {
		dph_send_response(conn);

	}

	dph_exit_conn(conn);
	return data;
}


static void *dph_acceptor(void *data)
{
	struct dph_conn *conn = (struct dph_conn *) data;
	struct sockaddr_in addr;
	int sfd, addrlen = sizeof(addr);

	while ((sfd = dph_accept(conn, (struct sockaddr *) &addr, &addrlen)) != -1) {
		if (dph_new_conn(sfd, dph_httpd) < 0) {
			dph_close(sfd);

		}
	}
	return data;
}


static struct dph_conn *dph_find(int sfd)
{
	struct list_head *head = &chash[sfd % chash_size], *lnk;
	struct dph_conn *conn;

	DBL_LIST_FOR_EACH(lnk, head) {
		conn = DBL_LIST_ENTRY(lnk, struct dph_conn, lnk);

		if (conn->sfd == sfd)
			return conn;
	}
	return NULL;
}


#ifdef _USE_EVENTPOLL

int dph_init(void)
{
	int ii;
	unsigned long mapsize;

	mapsize = EP_MAP_SIZE(maxsfd);

	if ((kdpfd = open("/dev/epoll", O_RDWR)) == -1) {
		perror("open() /dev/epoll");
		return -1;
	}
	if (ioctl(kdpfd, EP_ALLOC, maxsfd))
	{
		perror("ioctl() /dev/epoll");
		close(kdpfd);
		return -1;
	}
	if ((map = (char *) mmap(NULL, mapsize, PROT_READ | PROT_WRITE,
			MAP_PRIVATE, kdpfd, 0)) == (char *) -1)
	{
		perror("mmap() /dev/epoll");
		ioctl(kdpfd, EP_FREE, 0);
		close(kdpfd);
		return -1;
	}


	if (!(chash = (struct list_head *) malloc(maxsfd * sizeof(struct list_head)))) {
		perror("malloc()");
		munmap(map, mapsize);
		ioctl(kdpfd, EP_FREE, 0);
		close(kdpfd);
		return -1;
	}

	maxfds = maxsfd;
	chash_size = maxfds;
	for (ii = 0; ii < maxfds; ii++)
		DBL_INIT_LIST_HEAD(&chash[ii]);

	return 0;
}

int dph_cleanup(void)
{
	unsigned long mapsize;

	mapsize = EP_MAP_SIZE(maxfds);

	munmap(map, mapsize);
	ioctl(kdpfd, EP_FREE, 0);
	close(kdpfd);

	return 0;
}

static int dph_scheduler(void)
{
	int ii, nfds;
	static struct dph_conn *conn;
	struct pollfd *pfds;
	struct evpoll evp;

	for (;;) {
		evp.ep_timeout = STD_SCHED_TIMEOUT;
		evp.ep_resoff = 0;

		nfds = ioctl(kdpfd, EP_POLL, &evp);
		pfds = (struct pollfd *) (map + evp.ep_resoff);
		for (ii = 0; ii < nfds; ii++, pfds++) {
			if ((conn = dph_find(pfds->fd))) {
				conn->revents = pfds->revents;

				if (conn->revents & conn->events)
					co_call(conn->co, conn);
			}
		}
	}
	return 0;
}

#endif	/* #ifdef _USE_EVENTPOLL */


#ifdef _USE_DEVPOLL

int dph_init(void)
{
	int ii;
	unsigned long mapsize;

	mapsize = maxsfd * sizeof(struct pollfd);

	if ((kdpfd = open("/dev/poll", O_RDWR)) == -1) {
		perror("open() /dev/poll");
		return -1;
	}
	if (ioctl(kdpfd, DP_ALLOC, maxsfd))
	{
		perror("ioctl() /dev/poll");
		close(kdpfd);
		return -1;
	}
	if ((map = (char *) mmap(NULL, mapsize, PROT_READ | PROT_WRITE,
			MAP_PRIVATE, kdpfd, 0)) == (char *) -1)
	{
		perror("mmap() /dev/poll");
		ioctl(kdpfd, DP_FREE, 0);
		close(kdpfd);
		return -1;
	}
	if (!(chash = (struct list_head *) malloc(maxsfd * sizeof(struct list_head)))) {
		perror("malloc()");
		munmap(map, mapsize);
		ioctl(kdpfd, DP_FREE, 0);
		close(kdpfd);
		return -1;
	}

	maxfds = maxsfd;
	chash_size = maxfds;
	for (ii = 0; ii < maxfds; ii++)
		DBL_INIT_LIST_HEAD(&chash[ii]);

	return 0;
}

int dph_cleanup(void)
{
	unsigned long mapsize;

	mapsize = maxfds * sizeof(struct pollfd);

	munmap(map, mapsize);
	ioctl(kdpfd, DP_FREE, 0);
	close(kdpfd);
	return 0;
}

static int dph_scheduler(void)
{
	int ii, nfds;
	static struct dph_conn *conn;
	struct pollfd *pfds;
	struct dvpoll dvp;

	for (;;) {
		dvp.dp_nfds = maxfds;
		dvp.dp_fds = NULL;
		dvp.dp_timeout = STD_SCHED_TIMEOUT;

		nfds = ioctl(kdpfd, DP_POLL, &dvp);
		pfds = (struct pollfd *) map;
		for (ii = 0; ii < nfds; ii++, pfds++) {
			if ((conn = dph_find(pfds->fd))) {
				conn->revents = pfds->revents;

				if (conn->revents & conn->events)
					co_call(conn->co, conn);
			}
		}
	}
	return 0;
}

#endif	/* #ifdef _USE_DEVPOLL */


#ifdef _USE_STDPOLL

int dph_init(void)
{
	int ii;

	if (!(pfds = (struct pollfd *) malloc(maxsfd * sizeof(struct pollfd)))) {
		perror("malloc()");
		return -1;
	}

	if (!(chash = (struct list_head *) malloc(maxsfd * sizeof(struct list_head)))) {
		perror("malloc()");
		free(pfds);
		return -1;
	}

	maxfds = maxsfd;
	chash_size = maxfds;
	for (ii = 0; ii < maxfds; ii++)
		DBL_INIT_LIST_HEAD(&chash[ii]);

	return 0;
}

int dph_cleanup(void)
{
	free(pfds);
	return 0;
}

static int dph_scheduler(void)
{
	int ii, nfds, rfds;
	struct pollfd *cpfds;
	struct list_head *head, *lnk;
	static struct dph_conn *conn;

	for (;;) {
		for (ii = 0, nfds = 0, cpfds = pfds; ii < chash_size; ii++) {
			head = &chash[ii];
			DBL_LIST_FOR_EACH(lnk, head) {
				conn = DBL_LIST_ENTRY(lnk, struct dph_conn, lnk);

				cpfds->fd = conn->sfd;
				cpfds->events = conn->events;
				cpfds->revents = 0;
				++cpfds;
				++nfds;
			}
		}

		rfds = poll(pfds, nfds, STD_SCHED_TIMEOUT * 1000);
		for (ii = 0, cpfds = pfds; rfds > 0 && ii < nfds; ii++, cpfds++) {
			if (cpfds->revents && (conn = dph_find(cpfds->fd))) {
				--rfds;
				conn->revents = cpfds->revents;

				if (conn->revents & conn->events)
					co_call(conn->co, conn);
			}
		}
	}

	return 0;
}

#endif	/* #ifdef _USE_STDPOLL */


#ifdef _USE_RTSIGNALS

int dph_init(void)
{
	int ii;
	sigset_t sset;

	if (!(pfds = (struct pollfd *) malloc(maxsfd * sizeof(struct pollfd)))) {
		perror("malloc()");
		return -1;
	}

	if (!(chash = (struct list_head *) malloc(maxsfd * sizeof(struct list_head)))) {
		perror("malloc()");
		free(pfds);
		return -1;
	}

	rtsig = SIGRTMIN + 1;

	sigemptyset(&sset);
	sigaddset(&sset, rtsig);
	sigaddset(&sset, SIGIO);

	sigprocmask(SIG_BLOCK, &sset, NULL);

	maxfds = maxsfd;
	chash_size = maxfds;
	for (ii = 0; ii < maxfds; ii++)
		DBL_INIT_LIST_HEAD(&chash[ii]);

	return 0;
}

int dph_cleanup(void)
{
	free(pfds);
	return 0;
}

static int dph_scheduler(void)
{
	int sig, ii, nfds, rfds, topoll = 0;
	static struct dph_conn *conn;
	struct pollfd *cpfds;
	struct list_head *head, *lnk;
	sigset_t sset;
	siginfo_t sinfo;
	struct timespec ts;

	sigemptyset(&sset);
	sigaddset(&sset, SIGIO);
	sigaddset(&sset, rtsig);
	for (;;) {
		if (topoll) {
			for (ii = 0, nfds = 0, cpfds = pfds; ii < chash_size; ii++) {
				head = &chash[ii];
				DBL_LIST_FOR_EACH(lnk, head) {
					conn = DBL_LIST_ENTRY(lnk, struct dph_conn, lnk);

					cpfds->fd = conn->sfd;
					cpfds->events = conn->events;
					cpfds->revents = 0;
					++cpfds;
					++nfds;
				}
			}

			rfds = poll(pfds, nfds, STD_SCHED_TIMEOUT * 1000);
			for (ii = 0, cpfds = pfds; rfds > 0 && ii < nfds; ii++, cpfds++) {
				if (cpfds->revents && (conn = dph_find(cpfds->fd))) {
					--rfds;
					conn->revents = cpfds->revents;

					if (conn->revents & conn->events)
						co_call(conn->co, conn);
				}
			}
			topoll = 0;
		}

		memset(&sinfo, 0, sizeof(sinfo));
		ts.tv_sec = STD_SCHED_TIMEOUT;
		ts.tv_nsec = 0;

		sig = sigtimedwait(&sset, &sinfo, &ts);

		if (sig == rtsig) {
			if ((conn = dph_find(sinfo.si_fd))) {
				conn->revents = sinfo.si_band;

				if (conn->revents & conn->events)
					co_call(conn->co, conn);
			}
		} else if (sig == SIGIO) {
			printf("sig=(%d==SIGIO) fd=%d band=%d\n", sig, sinfo.si_fd, sinfo.si_band);

			ts.tv_sec = 0;
			ts.tv_nsec = 0;

			while (sigtimedwait(&sset, &sinfo, &ts) > 0);

			topoll = 1;
		}
	}
	return 0;
}

#endif	/* #ifdef _USE_RTSIGNALS */



void dph_usage(char const *prgname)
{

	fprintf(stderr,
			"use: %s [--msgsize nbytes (%d)] [--port nbr (%d)] [--maxfds nfds (%d)]\n\t[--stksize bytes (%d)]\n",
			prgname, msgsize, port, maxsfd, stksize);

}


int main(int argc, char *argv[])
{
	int ii, sfd, flags = 1;
	struct linger ling = {0, 0};
	struct sockaddr_in addr;

	for (ii = 1; ii < argc; ii++) {
		if (strcmp(argv[ii], "--msgsize") == 0) {
			if (++ii < argc)
				msgsize = atoi(argv[ii]);
			continue;
		}
		if (strcmp(argv[ii], "--port") == 0) {
			if (++ii < argc)
				port = atoi(argv[ii]);
			continue;
		}
		if (strcmp(argv[ii], "--maxfds") == 0) {
			if (++ii < argc)
				maxsfd = atoi(argv[ii]);
			continue;
		}
		if (strcmp(argv[ii], "--stksize") == 0) {
			if (++ii < argc)
				stksize = atoi(argv[ii]);
			continue;
		}

		dph_usage(argv[0]);
		return 1;
	}

	if (dph_init() == -1) {

		return 2;
	}

	if ((sfd = dph_socket(AF_INET, SOCK_STREAM, 0)) == -1) {

		dph_cleanup();
		return 3;
	}
	setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &flags, sizeof(flags));
	setsockopt(sfd, SOL_SOCKET, SO_KEEPALIVE, &flags, sizeof(flags));
	setsockopt(sfd, SOL_SOCKET, SO_LINGER, &ling, sizeof(ling));

	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	if (bind(sfd, (struct sockaddr *) &addr, sizeof(addr)) == -1) {

		dph_close(sfd);
		dph_cleanup();
		return 4;
	}

	listen(sfd, STD_LISTEN_SIZE);

	if (dph_new_conn(sfd, (void *) dph_acceptor) == -1) {

		dph_close(sfd);
		dph_cleanup();
		return 5;
	}

	dph_scheduler();

	dph_cleanup();
	return 0;
}
