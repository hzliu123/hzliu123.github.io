#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "hash.h"

static void hash_next_bucket(hash_table * hid);


/*
 *  hash_create - creates a new hash table, uses the cmp_func
 *  to compare keys.  Returns the identification for the hash table;
 *  otherwise returns a negative number on error.
 */
hash_table *
hash_create()
{
    hash_table *hid = calloc(1, sizeof(hash_table));
    /* allocate and null the buckets */
    hid->buckets = calloc(DEFAULT_HASH_SIZE, sizeof(hash_link *));
    hid->next = NULL;
    hid->current_slot = 0;
    return hid;
}

/*
 *  hash_join - joins a hash_link under its key lnk->key
 *  into the hash table 'hid'.  
 *
 *  It does not copy any data into the hash table, only links pointers.
 */
void
hash_join(hash_table * hid, hash_link * lnk)
{
    int i = HASH_FUNC(lnk->key, DEFAULT_HASH_SIZE);
    lnk->next = hid->buckets[i];
    hid->buckets[i] = lnk;
    hid->count++;
}

/*
 *  hash_lookup - locates the item under the key 'k' in the hash table
 *  'hid'.  Returns a pointer to the hash bucket on success; otherwise
 *  returns NULL.
 */
hash_link *
hash_lookup(hash_table * hid, const int k)
{
    hash_link *walker;
    int b = HASH_FUNC(k, DEFAULT_HASH_SIZE);

    for (walker = hid->buckets[b]; walker != NULL; walker = walker->next) {
	if (k == walker->key)
	    return (walker);
    }
    return NULL;
}

static void
hash_next_bucket(hash_table * hid)
{
    while (hid->next == NULL && ++hid->current_slot < DEFAULT_HASH_SIZE)
	hid->next = hid->buckets[hid->current_slot];
}

/*
 *  hash_first - initializes the hash table for the hash_next()
 *  function.
 */
void
hash_first(hash_table * hid)
{
    assert(NULL == hid->next);
    hid->current_slot = 0;
    hid->next = hid->buckets[hid->current_slot];
    if (NULL == hid->next)
	hash_next_bucket(hid);
}

/*
 *  hash_next - returns the next item in the hash table 'hid'.
 *  Otherwise, returns NULL on error or end of list.  
 *
 *  MUST call hash_first() before hash_next().
 */
hash_link *
hash_next(hash_table * hid)
{
    hash_link *this = hid->next;
    if (NULL == this)
	return NULL;
    hid->next = this->next;
    if (NULL == hid->next)
	hash_next_bucket(hid);
    return this;
}

/*
 *  hash_last - resets hash traversal state to NULL
 *
 */
void
hash_last(hash_table * hid)
{
    assert(hid);
    hid->next = NULL;
    hid->current_slot = 0;
}

/*
 *  hash_remove_link - deletes the given hash_link node from the 
 *  hash table 'hid'.  Does not free the item, only removes it
 *  from the list.
 *
 *  On success, it returns 0 and deletes the link; otherwise, 
 *  returns non-zero on error.
 */
void
hash_remove_link(hash_table * hid, hash_link * hl)
{
    hash_link **P;
    int i = HASH_FUNC(hl->key, DEFAULT_HASH_SIZE);
    for (P = &hid->buckets[i]; *P; P = &(*P)->next) {
	if (*P != hl)
	    continue;
	*P = hl->next;
	if (hid->next == hl) {
	    hid->next = hl->next;
	    if (NULL == hid->next)
		hash_next_bucket(hid);
	}
	hid->count--;
	return;
    }
    assert(0);
}

/*
 *  hash_get_bucket - returns the head item of the bucket 
 *  in the hash table 'hid'. Otherwise, returns NULL on error.
 */
hash_link *
hash_get_bucket(hash_table * hid, unsigned int bucket)
{
    if (bucket >= DEFAULT_HASH_SIZE)
	return NULL;
    return (hid->buckets[bucket]);
}

void
hashFreeItems(hash_table * hid)
{
    hash_link *l;
    hash_link **list;
    int i = 0;
    int j;
    list = (hash_link **)calloc(hid->count, sizeof(hash_link *));
    hash_first(hid);
    while ((l = hash_next(hid)) && i < hid->count) {
	*(list + i) = l;
	i++;
    }
    for (j = 0; j < i; j++)
	free(*(list + j));
    free(list);
}

void
hashFreeMemory(hash_table * hid)
{
    assert(hid);
    if (hid->buckets)
	free(hid->buckets);
    free(hid);
}
