#include "fdm.h"
#include "hash.h"
#include <sys/poll.h>
#include <sys/time.h>		/* gettimeofday */
#include <time.h>		/* nanosleep */
#include <stdlib.h>		/* malloc */
#include <stdio.h> 		/* printf */
#include <string.h>		/* memcpy */
#include <errno.h>
#include <assert.h>

static struct pollfd *interest_set_collect;
static unsigned int interest_set_collect_count;

/* all new fd events will be store here and retrieve via fdm_wait_event */
static fdm_event_t *fd_event_queue;

/* count number of fds in fd_event_queue */
static unsigned int fd_event_count;

static struct pollfd *interest_set[THREAD_NUM];
static void **interest_set_payload[THREAD_NUM];
static int *interest_set_live_counter[THREAD_NUM];
static struct timeval *interest_set_timer[THREAD_NUM];

/* count number of fds in each interest set */
static unsigned int interest_set_count[THREAD_NUM];

/* for finding where fd is in interest_sets */
static hash_table *fdhash;

/* lock fds at active polling set */
static int lock_array[LOCK_ARRAY_SIZE];
static unsigned int lock_count;

extern int errno;


int fdm_update_fd_mode(const struct pollfd *fds, void *payload, struct timeval *tv) {
        int i, j, lastfd, fdfound;
        int fd = fds->fd;
        short events = fds->events;
        hash_link *hl;
        
        fdfound = 0;

	
	hl = hash_lookup(fdhash, fd);
	if (hl != NULL) {
		i = hl->data >> 16;
		j = hl->data & 0x0000FFFF;
	
		interest_set[i][j].events = events;
		interest_set_payload[i][j] = payload;
		if (tv == NULL)
			timerclear(interest_set_timer[i]+j);
		else {
			interest_set_timer[i][j] = *tv;
//			printf("fd %d setup timer\n", fds->fd);
		}
	
		/* remove fd from fd_event_queue if any */

		for (i=0; i<fd_event_count; i++) {
			if (fd_event_queue[i].fd == fd) {
				lastfd = --fd_event_count;
				if (lastfd != i)
					fd_event_queue[i] = fd_event_queue[lastfd];
				break;
			}			
		}

		fdfound = 1;					
	}	

	return fdfound-1;
}


static int pow(int x, int y) {
	int result, i;
	result = 1;
	for (i=0; i<y; i++)
		result = result * x;
	
	return result;
}


static int is_lock(int fd) {
	int i;
	
	for (i=0; i<lock_count; i++)
		if (fd == lock_array[i])
			return TRUE;
			
	return FALSE;
}


int fdm_wait_event(fdm_event_t *ev_array, unsigned int array_size, int timeout) {
	int i, j, k, l, num, cnt, result, set_count_save[THREAD_NUM];
	int ret = 0;
	struct pollfd *mark[THREAD_NUM];
	void *dest, *src;
	struct pollfd *thisfd;
	struct timeval *thisfd_timer;
	struct timeval current_time;
	int *thisfd_lcnt;
	void **thisfd_payload;
	static unsigned int pollcnt = 0;
        hash_link *hl;

#define COND_NOEVENT 0
#define COND_ERROR 1
#define COND_OK 2

        int event_cond; 
        

	if (ev_array == NULL || array_size == 0) {
		errno = EINVAL;
		return -1;
	}

	gettimeofday(&current_time, NULL);

	/* generate polling fd set from all interest sets */
	pollcnt++;

	for (i=0; i<THREAD_NUM; i++) mark[i] = NULL;
	dest = interest_set_collect;
	interest_set_collect_count = 0;

	for (i=0; i<THREAD_NUM; i++) {
		if (pollcnt % pow(DEFAULT_LIVE_COUNTER, i) != 0)
			break;
		num = interest_set_count[i];
		if (num == 0) continue;
		src = interest_set[i];
		mark[i] = dest;
		memcpy(dest, src, sizeof(struct pollfd)*num);
		dest = (struct pollfd *)dest+num;
		interest_set_collect_count += num;
	}
	
	if (interest_set_collect_count == 0)
		return 0;

	result = poll(interest_set_collect, interest_set_collect_count, timeout);
	if (result == -1) {
		perror("poll()");
		return -1;
	} 

	num = fd_event_count;
	for (i=0; i<THREAD_NUM; i++)
		set_count_save[i] = interest_set_count[i];
	
	for (i=0; i<THREAD_NUM; i++) {
		if (mark[i] == NULL) continue;
		for (j=0; j<set_count_save[i]; j++) {
			thisfd = mark[i]+j;
			thisfd_lcnt = interest_set_live_counter[i]+j;
			thisfd_payload = interest_set_payload[i]+j;
			thisfd_timer = interest_set_timer[i]+j;

			
			/* classify event */
	
			if (thisfd->revents == 0)	{
				if (timerisset(thisfd_timer) && timercmp(thisfd_timer, &current_time, <)) {
					thisfd->revents = POLLTIMEOUT;
					event_cond = COND_ERROR;
//					printf("fd timeout: %d\n", thisfd->fd);
				} else
					event_cond = COND_NOEVENT;
			} else if (thisfd->revents & (POLLERR | POLLHUP | POLLNVAL)) {
				timerclear(thisfd_timer);	
				event_cond = COND_ERROR;

			} else {
				timerclear(thisfd_timer);
				event_cond = COND_OK;
			}

			
			/* fill event queue */			
	
			if (event_cond == COND_OK || event_cond == COND_ERROR) {
				if (fd_event_count >= FD_QUEUE_SIZE) {
					fprintf(stderr, "fd_event_queue full!\n");
				} else {
					/* find previous event, and overwrite it */
					for (k=0; k<num; k++)
						if (fd_event_queue[k].fd == thisfd->fd) {
							fd_event_queue[k].events = thisfd->revents;
							/* payload doesn't need to update, because
							   updating payload remove fd events from 
							   queue */
							break;
						}
					/* didn't find previous event, put new event at last slot */
					if (k >= num) {
						fd_event_queue[fd_event_count].fd = thisfd->fd;
						fd_event_queue[fd_event_count].events = thisfd->revents;
						fd_event_queue[fd_event_count].payload = *thisfd_payload;
						fd_event_count++;
					} else {
						/* Previous event found in fd_event_queue.
						   This means there is the events is not return
			   			   to callers at last call of fdm_wait_event()
			   			   We neither increase live counter nor change 
						   fd state under the condition. 
			   			   TIMEOUT, ERR, HUP, NVAL are excluded */
						if (event_cond == COND_OK) continue;
					}		
				}
			}	

			/* update live counter */
			if (is_lock(thisfd->fd)) continue;

			switch (event_cond) {
			case COND_OK:
				/* got event, increase live counter */
				if (*thisfd_lcnt < DEFAULT_LIVE_COUNTER - 1) {
					/* no event at previous poll() */
					*thisfd_lcnt = DEFAULT_LIVE_COUNTER-1;
				} else {
					/* has event at last poll() */
					if (*thisfd_lcnt < DEFAULT_LIVE_COUNTER)
						(*thisfd_lcnt)++;
				}	
				break;
	
			case COND_ERROR:
			case COND_NOEVENT:
				/* no event at this poll, decrease live counter */
				if (*thisfd_lcnt > 0)
					(*thisfd_lcnt)--;	
				break;
			}	
	
	
			/* moving fd among state according to live counter */
	
			if (i < THREAD_NUM-1 && *thisfd_lcnt <= 0) {
				/* downgrade state */
				k = i+1;
				l = interest_set_count[k]++;
				hl = hash_lookup(fdhash, thisfd->fd);
				assert(hl != NULL);
				hl->data = ((k << 16) | l);
		
				interest_set[k][l] = interest_set[i][j];
				interest_set_payload[k][l] = *thisfd_payload;
				interest_set_live_counter[k][l] = DEFAULT_LIVE_COUNTER - 2;
				interest_set_timer[k][l] = *thisfd_timer;
				interest_set[i][j].fd = -1; /* del later */
//				printf("fd %d downgrade from %d to %d\n", thisfd->fd, i, i+1);
			} else if (i > 0 && *thisfd_lcnt >= DEFAULT_LIVE_COUNTER) {
				/* upgrade to active state */
				l = interest_set_count[0]++;
				hl = hash_lookup(fdhash, thisfd->fd);
				assert(hl != NULL);
				hl->data = l;
		
				interest_set[0][l] = interest_set[i][j];
				interest_set_payload[0][l] = *thisfd_payload;
				interest_set_live_counter[0][l] = DEFAULT_LIVE_COUNTER - 2;
				interest_set_timer[0][l] = *thisfd_timer;
				interest_set[i][j].fd = -1; /* del later */
//				printf("fd %d upgrade from %d to 0\n", thisfd->fd, i);
			}	
		}

		j = 0;
		cnt = interest_set_count[i];
		for (k=0; k<cnt; k++) {
			if (interest_set[i][k].fd == -1) continue;
			if (k != j) {
				hl = hash_lookup(fdhash, interest_set[i][k].fd);
				hl->data = ((hl->data & 0xFFFF0000) | j);
	
				interest_set[i][j] = interest_set[i][k];
				interest_set_live_counter[i][j] = interest_set_live_counter[i][k];
				interest_set_payload[i][j] = interest_set_payload[i][k];
				interest_set_timer[i][j] = interest_set_timer[i][k];
			}
			j++;
		}
		interest_set_count[i] = j;
	}

	if (fd_event_count != 0) {
		num = fd_event_count < array_size ? fd_event_count : array_size;
		memcpy(ev_array, fd_event_queue, sizeof(fdm_event_t)*num);
		ret = num;
		fd_event_count = fd_event_count - num;
	
		if (fd_event_count != 0) {
			memmove(fd_event_queue, fd_event_queue+num, sizeof(fdm_event_t)*fd_event_count);
		}				
	}
	return ret;
}


int fdm_reg_fd(const struct pollfd *fds, int lock) {
	int ret, i;
	hash_link *hl;

	/* critical section */
	
	if (interest_set_count[0] >= INTEREST_SET_SIZE) {
		fprintf(stderr, "interest_set_count[0] reaches size limit!\n");
		ret = -1;
	} else {
//		printf("reg_fd: %d\n", fds->fd);
		i = interest_set_count[0]++;
		interest_set[0][i] = *fds;
		interest_set[0][i].revents = 0;
		interest_set_payload[0][i] = NULL;
		timerclear(interest_set_timer[0]+i);
		interest_set_live_counter[0][i] = DEFAULT_LIVE_COUNTER-1;
		hl = (hash_link *)malloc(sizeof(hash_link));
		hl->key = fds->fd;
		hl->data = i;
		hash_join(fdhash, hl);
		
		if (lock && lock_count < LOCK_ARRAY_SIZE)		
			lock_array[lock_count++] = fds->fd;
				
		ret = 0;
	}
	return ret;
}



/* remove fd from interest_set, also remove fd event from event queue if any */
int fdm_unreg_fd(int fd) {
        int i, j, lastfd, fdfound;
        hash_link *hl;
        
        fdfound = 0;

	hl = hash_lookup(fdhash, fd);
	if (hl != NULL) {
		hash_remove_link(fdhash, hl);
		i = hl->data >> 16;
		j = hl->data & 0x0000FFFF;
		free(hl);
//		printf("unreg_fd: %d\n", fd);
			
		lastfd = --interest_set_count[i];
		if (lastfd != j) {
			hl = hash_lookup(fdhash, interest_set[i][lastfd].fd);
			hl->data = ((hl->data & 0xFFFF0000) | j);
			interest_set[i][j] = interest_set[i][lastfd];
			interest_set_payload[i][j] = interest_set_payload[i][lastfd];
			interest_set_live_counter[i][j] = interest_set_live_counter[i][lastfd];
			interest_set_timer[i][j] = interest_set_timer[i][lastfd];
		}

		
		/* remove fd from fd_event_queue if any */

		for (i=0; i<fd_event_count; i++) {
			if (fd_event_queue[i].fd == fd) {
				lastfd = --fd_event_count;
				if (lastfd != i)
					fd_event_queue[i] = fd_event_queue[lastfd];
				break;
			}			
		}
		
		/* remove fd from lock array if any */
		
		for (i=0; i<lock_count; i++) {
			if (lock_array[i] == fd) {
				lastfd = --lock_count;
				if (lastfd != i)
					lock_array[i] = lock_array[lastfd];
				break;		
			}
		}

		fdfound = 1;	
	} 
	
	return fdfound-1;
}


int fdm_start() {
	int i;


	fd_event_count = 0;
	lock_count = 0;
	fd_event_queue = (fdm_event_t *)malloc(sizeof(fdm_event_t)*FD_QUEUE_SIZE);
	fdhash = hash_create();

	interest_set_collect = (struct pollfd *)malloc(sizeof(struct pollfd)*INTEREST_SET_SIZE);

	for (i=0; i<THREAD_NUM; i++) {
		interest_set_count[i] = 0;
		interest_set[i] = (struct pollfd *)malloc(sizeof(struct pollfd)*INTEREST_SET_SIZE);
		interest_set_payload[i] = (void **)malloc(sizeof(void *)*INTEREST_SET_SIZE);
		interest_set_live_counter[i] = (int *)malloc(sizeof(int)*INTEREST_SET_SIZE);
		interest_set_timer[i] = (struct timeval *)malloc(sizeof(struct timeval)*INTEREST_SET_SIZE);	

	}
	return 0;
}


int fdm_stop() {
	int i;

	free(interest_set_collect);
	
	/* free memory */

	for (i=0; i<THREAD_NUM; i++) {
		free(interest_set[i]);
		free(interest_set_payload[i]);
		free(interest_set_live_counter[i]);
		free(interest_set_timer[i]);
	}	

	hashFreeItems(fdhash);
	hashFreeMemory(fdhash);
	free(fd_event_queue);

	return 0;
}
