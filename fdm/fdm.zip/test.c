#include "fdm.h"
#include <unistd.h>


int main() {
	fdm_start();

			
	fdm_stop();


	return 0;
}

