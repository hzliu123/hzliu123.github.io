#ifndef FDM_H
#define FDM_H

#include <sys/poll.h>
#include <sys/resource.h>
#include <unistd.h>

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#define FD_QUEUE_SIZE 8192
#define INTEREST_SET_SIZE 20480
#define LOCK_ARRAY_SIZE 128
#define THREAD_NUM 3

/* setting live counter influence response time and CPU usage
   lower one make better response time but high CPU usage.
   higher one make lower CPU usage but longer response time.
*/
#define DEFAULT_LIVE_COUNTER 3

/* check <bits/poll.h> for other bit pattern of poll() 
   Each fd in FDM has an associated timer, it is updated
   at every called to fdm_update_fd_mode(). 
*/

#define POLLTIMEOUT 0x800

typedef struct {
   int fd;
   short events;
   void *payload;
} fdm_event_t;

int fdm_start();
int fdm_stop();
int fdm_reg_fd(const struct pollfd *fds, int lock);
int fdm_unreg_fd(int fd);
int fdm_update_fd_mode(const struct pollfd *fds, void *payload, struct timeval *tv);

/* ev_array space is given by users, size is specified in array_size
   if timeout = -1, the function block until it gets events 
*/
int fdm_wait_event(fdm_event_t *ev_array, unsigned int array_size, int timeout);

#endif
